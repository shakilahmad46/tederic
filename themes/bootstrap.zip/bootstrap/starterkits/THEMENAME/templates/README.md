This directory is used to implement various core, contrib, Bootstrap and custom
templates.

Please refer to the [Templates](<!-- @url templates -->) topic for more info.
