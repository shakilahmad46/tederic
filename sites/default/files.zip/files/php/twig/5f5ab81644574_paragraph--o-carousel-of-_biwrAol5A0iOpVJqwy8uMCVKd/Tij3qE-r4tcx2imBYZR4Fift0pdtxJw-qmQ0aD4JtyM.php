<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* themes/tederic/templates/paragraph/paragraph--o-carousel-of-images.html.twig */
class __TwigTemplate_af907423d28beb59439e051e41c6c4796e892150afbf3d67fbb7ef24787e2aa3 extends \Twig\Template
{
    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = [
        ];
        $this->sandbox = $this->env->getExtension('\Twig\Extension\SandboxExtension');
        $tags = [];
        $filters = ["escape" => 7];
        $functions = [];

        try {
            $this->sandbox->checkSecurity(
                [],
                ['escape'],
                []
            );
        } catch (SecurityError $e) {
            $e->setSourceContext($this->getSourceContext());

            if ($e instanceof SecurityNotAllowedTagError && isset($tags[$e->getTagName()])) {
                $e->setTemplateLine($tags[$e->getTagName()]);
            } elseif ($e instanceof SecurityNotAllowedFilterError && isset($filters[$e->getFilterName()])) {
                $e->setTemplateLine($filters[$e->getFilterName()]);
            } elseif ($e instanceof SecurityNotAllowedFunctionError && isset($functions[$e->getFunctionName()])) {
                $e->setTemplateLine($functions[$e->getFunctionName()]);
            }

            throw $e;
        }

    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        // line 1
        echo "<div class=\"automo lens-sec1 news-in\">
                <div class=\"row\">
                    <div class=\"col-md-12 col-sm-12 col-xs-12\">
                        <div class=\"slider-area-main\">
                            <div id=\"myCarousel\" class=\"carousel slide\" data-ride=\"carousel\">
                                <div class=\"carousel-inner\">
                                    ";
        // line 7
        echo $this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed($this->getAttribute(($context["content"] ?? null), "field_carousel_content", [])), "html", null, true);
        echo "
                                </div>

                                <!-- Left and right controls -->
                                <!--<a class=\"left carousel-control\" href=\"#myCarousel\" data-slide=\"prev\">
      <img src=\"images/slarrow-left.png\">
    </a>-->
                                <div class=\"lens-arow\">
                                    <ol class=\"carousel-indicators\">
                                        <li data-target=\"#myCarousel\" data-slide-to=\"0\" class=\"active\">1/4</li>
                                        <li data-target=\"#myCarousel\" data-slide-to=\"1\">2/4</li>
                                        <li data-target=\"#myCarousel\" data-slide-to=\"2\" class=\"\">3/4</li>
                                    </ol>
                                    <a class=\"right carousel-control\" href=\"#myCarousel\" data-slide=\"next\">
                                        <img src=\"images/slarrow-right.png\">
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>";
    }

    public function getTemplateName()
    {
        return "themes/tederic/templates/paragraph/paragraph--o-carousel-of-images.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  63 => 7,  55 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Source("<div class=\"automo lens-sec1 news-in\">
                <div class=\"row\">
                    <div class=\"col-md-12 col-sm-12 col-xs-12\">
                        <div class=\"slider-area-main\">
                            <div id=\"myCarousel\" class=\"carousel slide\" data-ride=\"carousel\">
                                <div class=\"carousel-inner\">
                                    {{ content.field_carousel_content }}
                                </div>

                                <!-- Left and right controls -->
                                <!--<a class=\"left carousel-control\" href=\"#myCarousel\" data-slide=\"prev\">
      <img src=\"images/slarrow-left.png\">
    </a>-->
                                <div class=\"lens-arow\">
                                    <ol class=\"carousel-indicators\">
                                        <li data-target=\"#myCarousel\" data-slide-to=\"0\" class=\"active\">1/4</li>
                                        <li data-target=\"#myCarousel\" data-slide-to=\"1\">2/4</li>
                                        <li data-target=\"#myCarousel\" data-slide-to=\"2\" class=\"\">3/4</li>
                                    </ol>
                                    <a class=\"right carousel-control\" href=\"#myCarousel\" data-slide=\"next\">
                                        <img src=\"images/slarrow-right.png\">
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>", "themes/tederic/templates/paragraph/paragraph--o-carousel-of-images.html.twig", "C:\\Users\\shaki\\Sites\\devdesktop\\tederic\\themes\\tederic\\templates\\paragraph\\paragraph--o-carousel-of-images.html.twig");
    }
}
